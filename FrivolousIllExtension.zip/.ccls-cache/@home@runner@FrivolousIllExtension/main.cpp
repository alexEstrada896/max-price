#include <iostream> // Includes the iostream library, // is comment need to have

using namespace std; // Using the standard namespace, need to have

//main function always needed 
//we will make program to add two numbers

int main() {
string items [6] = {"Milk", "Bread", "Chocolate", "Towel", "Toothpaste","Soap"};
double price [6] = {3.00,7.25,5.00,7.50,4.00,10.50};
double  max = price [0];
int j = 0;
  for (int i =0; i<6 ;i++){
   if( price [i] > max){
     max =price [i];
     j = i;
   } 
  }
cout << "the most expensive tem is "<< items [j]<< endl;
  cout << "the max price is:"<< max <<endl;
  



  return 0;
}